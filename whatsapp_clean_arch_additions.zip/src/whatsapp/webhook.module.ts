import { Module } from '@nestjs/common';
import { WebhookController } from './interface/controllers/webhook.controller';
import { WebhookService } from './interface/services/webhook.service';

import { WhatsappMessengerAdapter } from './infrastructure/messaging/whatsapp.messenger.adapter';
import { MemorySessionStore } from './infrastructure/session/memory.session.store';

import { HandleIncomingMessageUseCase } from './application/use-cases/handle-incoming-message.use-case';
import { EventsModule } from '../events/bookings.module'; // provee 'BookingRepository'

@Module({
  imports: [EventsModule],
  controllers: [WebhookController],
  providers: [
    WebhookService,
    WhatsappMessengerAdapter,
    MemorySessionStore,
    {
      provide: HandleIncomingMessageUseCase,
      useFactory: (
        messenger: WhatsappMessengerAdapter,
        store: MemorySessionStore,
        bookingRepo: any, // token 'BookingRepository' desde EventsModule
      ) => new HandleIncomingMessageUseCase(messenger, store, bookingRepo),
      inject: [WhatsappMessengerAdapter, MemorySessionStore, 'BookingRepository'],
    },
  ],
})
export class WebhookModule {}
