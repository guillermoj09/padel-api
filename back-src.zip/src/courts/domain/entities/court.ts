export class Court {
  constructor(
    public readonly id: number,
    public readonly name: string,
    public readonly active: boolean = true,
  ) {}
}