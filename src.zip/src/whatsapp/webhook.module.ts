// src/webhook/webhook.module.ts
import { Module } from '@nestjs/common';
import { WebhookController } from './interface/controllers/webhook.controller';
import { WebhookService } from './interface/services/webhook.service';

@Module({
  controllers: [WebhookController],
  providers: [WebhookService],
})
export class WebhookModule {}
