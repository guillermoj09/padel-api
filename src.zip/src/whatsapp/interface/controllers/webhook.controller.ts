// src/webhook/webhook.controller.ts
import {
  Controller,
  Get,
  Post,
  Query,
  Headers,
  Body,
  Res,
  HttpCode,
} from '@nestjs/common';
import { Response } from 'express';
import { WebhookService } from '../services/webhook.service';

// --- estado en memoria por contacto ---
type Step =
  | 'idle'
  | 'choose_cancha'
  | 'choose_date'
  | 'awaiting_other_date'
  | 'choose_time'; // <- solo este paso será texto libre

type Session = { step: Step; cancha?: number; date?: string; time?: string };
const SESSIONS = new Map<string, Session>();

const CANCHA_BTNS = [
  { id: 'cancha_1', title: 'Cancha 1' },
  { id: 'cancha_2', title: 'Cancha 2' },
  { id: 'cancha_3', title: 'Cancha 3' },
];

const DATE_BTNS = [
  { id: 'date_today', title: 'Hoy' },
  { id: 'date_tomorrow', title: 'Mañana' },
  { id: 'date_other', title: 'Otro día' },
];

const TZ = 'America/Santiago';

// Helpers
function ensureSession(phone: string): Session {
  const s = SESSIONS.get(phone) ?? { step: 'idle' as Step };
  SESSIONS.set(phone, s);
  return s;
}
function formatYMD(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
function parseYMD(s: string): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return null;
  const [y, m, d] = s.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d, 12, 0, 0)); // mediodía UTC para evitar DST edge cases
  return isNaN(dt.getTime()) ? null : dt;
}
function isSameLocalDate(dateStr: string, tz: string): boolean {
  const now = new Date();
  const fmt = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' });
  const nowYMD = fmt.format(now); // yyyy-mm-dd
  return nowYMD === dateStr;
}
function getLocalHour(tz: string): number {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: tz,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(new Date());
  const hh = Number(parts.find(p => p.type === 'hour')?.value ?? '0');
  const mm = Number(parts.find(p => p.type === 'minute')?.value ?? '0');
  // redondeo a la siguiente hora si estamos pasada la media
  return hh + (mm >= 30 ? 1 : 0);
}

// Lista base de horas (09:00–20:00), filtrando pasadas si es hoy
function getAvailableHours(dateStr: string): string[] {
  const base = [
    '09:00','10:00','11:00','12:00','13:00','14:00',
    '15:00','16:00','17:00','18:00','19:00','20:00',
  ];
  if (!isSameLocalDate(dateStr, TZ)) return base;
  const h = getLocalHour(TZ);
  return base.filter(t => Number(t.slice(0, 2)) >= h);
}

function isValidHHmm(s: string): boolean {
  if (!/^\d{2}:\d{2}$/.test(s)) return false;
  const [hh, mm] = s.split(':').map(Number);
  return hh >= 0 && hh <= 23 && mm >= 0 && mm <= 59;
}

function listHoursMsg(dateStr: string): string {
  const hours = getAvailableHours(dateStr);
  if (!hours.length) {
    return `No quedan horas disponibles para *${dateStr}*.\nEscribe "mañana" o una fecha en formato YYYY-MM-DD.`;
  }
  return (
    `📅 Fecha *${dateStr}* seleccionada.\n` +
    `Horarios disponibles: ${hours.join(', ')}\n` +
    `\nEscribe la *hora* en formato 24h HH:mm (ej: 18:30).`
  );
}

@Controller('webhook/whatsapp')
export class WebhookController {
  constructor(private readonly svc: WebhookService) {}

  @Get()
  verify(
    @Query('hub.mode') mode: string,
    @Query('hub.verify_token') token: string,
    @Query('hub.challenge') challenge: string,
    @Res() res: Response,
  ) {
    if (mode === 'subscribe' && token === process.env.WHATSAPP_VERIFY_TOKEN) {
      return res.status(200).send(challenge);
    }
    return res.sendStatus(403);
  }

  @Get('test')
  getHello(): string {
    return 'GET de prueba funcionando 🚀';
  }

  @Post()
  @HttpCode(200)
  async receive(
    @Headers('x-hub-signature-256') signature: string,
    @Body() body: any,
  ) {
    console.log('[WA][POST] body:', JSON.stringify(body, null, 2));

    const value = body?.entry?.[0]?.changes?.[0]?.value;
    if (!value) return;

    if (Array.isArray(value.statuses) && value.statuses.length) return;

    const msg = value?.messages?.[0];
    if (!msg) return;

    const from: string | undefined = msg.from;
    const text: string | undefined = msg.text?.body;
    const buttonId: string | undefined = msg.interactive?.button_reply?.id;
    const listId: string | undefined = msg.interactive?.list_reply?.id;

    const payload = (text ?? buttonId ?? listId ?? '').trim();
    if (!from || !payload) return;

    const p = payload.toLowerCase();
    const session = ensureSession(from);
    console.log('[WA] from:', from, 'payload:', payload, 'session:', session);

    // === MENU ===
    if (p.includes('menu')) {
      session.step = 'idle';
      session.cancha = undefined;
      session.date = undefined;
      session.time = undefined;
      await this.svc.sendButtons(from, '¿Qué necesitas?', [
        { id: 'opt_reserve', title: 'Reservar cancha' },
      ]);
      return;
    }

    // === RESERVA ===
    if (payload === 'opt_reserve') {
      session.step = 'choose_cancha';
      session.cancha = undefined;
      session.date = undefined;
      session.time = undefined;
      await this.svc.sendButtons(from, 'Elige la cancha:', CANCHA_BTNS);
      return;
    }

    // 1) elegir cancha
    if (session.step === 'choose_cancha' && payload.startsWith('cancha_')) {
      const num = Number(payload.split('_')[1]);
      if ([1, 2, 3].includes(num)) {
        session.cancha = num;
        session.step = 'choose_date';
        await this.svc.sendButtons(
          from,
          `Cancha ${num} seleccionada ✅\nAhora elige la fecha:`,
          DATE_BTNS,
        );
        return;
      } else {
        await this.svc.sendButtons(from, 'Cancha inválida. Elige una:', CANCHA_BTNS);
        return;
      }
    }

    // 2) elegir fecha
    if (session.step === 'choose_date') {
      if (payload === 'date_today') {
        session.date = new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
        session.step = 'choose_time';
      } else if (payload === 'date_tomorrow') {
        const now = new Date();
        const fmt = new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' });
        const [y, m, d] = fmt.format(now).split('-').map(Number);
        const dt = new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
        dt.setUTCDate(dt.getUTCDate() + 1);
        session.date = formatYMD(dt);
        session.step = 'choose_time';
      } else if (payload === 'date_other') {
        session.step = 'awaiting_other_date';
        await this.svc.sendText(from, 'Escribe la fecha en formato YYYY-MM-DD (ej: 2025-08-21).');
        return;
      }

      if (session.step === 'choose_time' && session.date) {
        const msgTxt = listHoursMsg(session.date);
        await this.svc.sendText(from, msgTxt);
        return;
      }
    }

    // fecha manual
    if (session.step === 'awaiting_other_date' && text) {
      const dt = parseYMD(text.trim());
      if (!dt) {
        await this.svc.sendText(from, 'Formato inválido. Usa YYYY-MM-DD (ej: 2025-08-21).');
        return;
      }
      session.date = formatYMD(dt);
      session.step = 'choose_time';

      const msgTxt = listHoursMsg(session.date);
      await this.svc.sendText(from, msgTxt);
      return;
    }

    // 3) elegir hora (TEXTO, sin botones)
    if (session.step === 'choose_time' && text) {
      const t = text.trim();
      if (!isValidHHmm(t)) {
        await this.svc.sendText(from, 'Hora inválida. Usa el formato HH:mm (24h), ej: 18:30');
        return;
      }

      // Validar que esté dentro de los disponibles para esa fecha
      const avail = getAvailableHours(session.date!);
      if (!avail.includes(t)) {
        if (!avail.length) {
          await this.svc.sendText(
            from,
            `No quedan horas disponibles para *${session.date}*.\nEscribe "mañana" o una fecha en formato YYYY-MM-DD.`
          );
          return;
        }
        await this.svc.sendText(
          from,
          `Esa hora no está disponible para *${session.date}*.\nHorarios disponibles: ${avail.join(', ')}\nEnvía una hora válida (HH:mm).`
        );
        return;
      }

      session.time = t;
      session.step = 'idle';

      if (session.cancha && session.date && session.time) {
        await this.svc.sendText(
          from,
          `✅ Reserva preparada:\n• Cancha: ${session.cancha}\n• Fecha: ${session.date}\n• Hora: ${session.time}\n\nEscribe "menu" para volver.`
        );
        return;
      }
    }

    // === fallback ===
    await this.svc.sendText(
      from,
      `Recibido: ${payload}\nEscribe "menu" para ver opciones.`
    );
  }
}
