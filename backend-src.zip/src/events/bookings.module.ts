import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BookingSchema } from './infrastructure/typeorm/entities/booking.schema';
import { TypeOrmBookingRepository } from './infrastructure/typeorm/booking.repository.typeorm';
import { CreateBookingUseCase } from './application/use-cases/create-booking.use-case';
import { GetBookingsUseCase } from './application/use-cases/get-booking.use-case';
import { BookingController } from './interface/controllers/booking.controller';

@Module({
  imports: [TypeOrmModule.forFeature([BookingSchema])],
  controllers: [BookingController],
  providers: [
    CreateBookingUseCase,
    GetBookingsUseCase,
    {
      provide: 'BookingRepository',
      useClass: TypeOrmBookingRepository,
    },
  ],
})
export class EventsModule {}
