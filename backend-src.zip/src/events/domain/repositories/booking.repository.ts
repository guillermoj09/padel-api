import { Booking } from '../entities/booking';

export interface BookingRepository {
  findAll(): Promise<Booking[]>;
  create(booking: Omit<Booking, 'id'>): Promise<Booking>;
}
