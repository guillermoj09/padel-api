import { Body, Controller, Post } from '@nestjs/common';
import { CreateBookingUseCase } from '../../application/use-cases/create-booking.use-case';

export class CreateBookingDto {
  userId: string;
  courtId: number;
  startTime: Date;
  endTime: Date;
}

@Controller('bookings')
export class BookingController {
  constructor(private readonly createBookingUseCase: CreateBookingUseCase) {}

  @Post()
  async createBooking(@Body() dto: CreateBookingDto) {
    console.log(`aa ${dto.userId}`);
    const bookingInput = {
      userId: dto.userId,
      courtId: dto.courtId,
      paymentId: null,
      startTime: new Date(dto.startTime),
      endTime: new Date(dto.endTime),
      status: 'pendiente',
      date: new Date(), // ahora
    };

    return this.createBookingUseCase.execute(bookingInput);
  }
}
